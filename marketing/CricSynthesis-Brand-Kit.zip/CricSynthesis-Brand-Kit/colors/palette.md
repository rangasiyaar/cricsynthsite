# CricSynthesis colour palette

| Token | Light | Dark | Use |
|---|---|---|---|
| `bg` | #f2f2f3 | #111315 | Page background. Paper grey, never pure white. |
| `surface` | #e9e9ea | #1a1d20 | Raised areas on bg: hover fills, segmented controls, icon tiles. |
| `ink` | #1d1f20 | #e6e7e8 | Headings and primary text on bg and surface (15:1 light, 14:1 dark). |
| `ink-2` | #45484b | #b6babe | Body copy and ledes on bg. |
| `ink-3` | #5d5d60 | #8f9499 | Captions, meta, fine print, axis labels (5.9:1 light, 6.1:1 dark). |
| `line` | rgba(29, 31, 32, 0.16) | rgba(230, 231, 232, 0.14) | 1px dividers, card and input borders. The brand separates with lines, not shadows. |
| `steel` | #5980a6 | #5980a6 | Brand blue: logo mark, primary button fill, focus ring, chart team A. Paper text on it is 3.7:1, below AA for small text: see Button. |
| `steel-700` | #416180 | #8fb3d9 | Accent text and links on bg (5.8:1 light, 8.5:1 dark); the SYNTHESIS half of the wordmark; button hover. |
| `steel-800` | #2c455d | #b5d9fd | Link hover; strong accent on bg. |
| `steel-900` | #1d2d3d | #172431 | Navy ground: offer bands, API code panels, footers, the closing call-to-action band. |
| `steel-100` | #eef6ff | #1f3347 | Light tint behind accent content; hover on light buttons. |
| `steel-200` | #d6ebff | #1f3347 | Chart area fill (projected-score bands, the cricket field in illustrations). |
| `steel-300` | #b5d9fd | #b5d9fd | Accent text and buttons on steel-900 (9.6:1). |
| `steel-400` | #94bce3 | #94bce3 | Labels and eyebrows on steel-900 (7:1); illustration line work. |
| `paper` | #f2f2f3 | #f2f2f3 | Text and buttons on steel and steel-900, the same in both themes. |
| `clay` | #b0613a | #d9895f | Second team in every two-team chart, wicket rings, savings badges. 4.1:1 on light bg: use for graphics and text 24px and up only; small text stays ink. |
| `success` | #3f7d5c | #74c296 | Positive state: confirmations, live-and-healthy. |
| `warn` | #8a6a1f | #d9b766 | Caution state: limits nearly reached, pending. |
| `danger` | #a8443b | #e48a80 | Errors and destructive actions only, never as a team colour. |

# CricSynthesis

AI-Powered Cricket Intelligence. CricSynthesis simulates every ball of a cricket match before it is played and turns that into analytics and projections: win chances, projected runs and wickets, player ratings, match-ups and fantasy picks. Fans get it on the website and the Android app (CricSynthesis Pro); businesses get it through one API, an MCP connector for AI assistants, and ready-to-post graphics.

This kit is the reusable CricSynthesis brand: logos, colours, fonts, tokens and a starter stylesheet, with the rules for using them.

## What's in the kit

| Folder | Contents |
|---|---|
| `logos/svg/` | `mark-original.svg` (master mark), `mark-steel.svg`, `mark-steel-light.svg`, `mark-ink.svg`, `mark-white.svg`, `favicon.svg` |
| `logos/png/` | Transparent lockups: `lockup-on-light.png`, `lockup-on-dark.png`, `lockup-black.png`, `lockup-white.png`; marks `mark-steel-1024.png`, `mark-white-1024.png`; `app-icon-1024.png`, `link-preview-1200x630.png`, `email-header-525x102.png` |
| `colors/` | `tokens.json` (every colour, type style, space and radius, light and dark), `tokens.css` (CSS custom properties), `palette.md` (the table below with usage) |
| `fonts/` | Barlow, Barlow Condensed and JetBrains Mono (TTF) with their SIL Open Font License files |
| `css/brand.css` | Fonts, tokens and starter classes: type styles, logo lockup, buttons, navy band, cards, two-team colours |

Tokens are the source of truth; use them by name (`--steel-700`, `--clay`, `--font-head`).

## Products and how to name them

| Product | Who it is for | Price | Call to action |
| --- | --- | --- | --- |
| CricSynthesis Free | Every fan | ₹0, no account needed | See today's matches |
| CricSynthesis Pro | Fans who want the full match centre and MatchSynth Lab | ₹349 a month or ₹3,769 a year, 1 day free | Start your free day |
| API Free | Developers trying it out | ₹0, 200 calls a day | Create a free key |
| API Plus | Developers, creators, fantasy tools | ₹4,999 a month or ₹53,989 a year, Pro included | Get your API key |
| Business API | Publishers, broadcasters, sports platforms | Priced to their traffic | Book a call |

- Write **CricSynthesis** as one word with a capital C and S. In the logo it is set in capitals, CRIC in ink and SYNTHESIS in steel-700.
- **MatchSynth Lab** is the in-browser scenario simulator. **Match centre** is the set of tabs for one match. **Overview** is the free tab.
- Prices are in rupees with the ₹ sign and Indian digit grouping (₹3,769, ₹53,989). Say "a month", "a year", not "/mo".

## Voice

We sound like a sharp cricket analyst talking to a fan: plain words, one idea per sentence, numbers with their range.

- **Say what the number is.** "IND 62% to win", "184, likely 166–201". Projections are model expectations, so show the likely range wherever we have one.
- **Use cricket's own terms.** Projected runs, projected wickets, danger overs, player match-ups, powerplay, death overs. Never "AI predictions" or "guaranteed".
- **Sentence case for copy, uppercase only for headings and eyebrows** (set by the type styles, not typed in capitals).
- **What we never say.** We sell analytics and projections, never live scores or raw data. No betting language (odds, bets, tips, sure-shot). We don't name our data sources anywhere except the Data credits page, and we don't name payment, email or hosting providers in product copy or emails.
- **Accounts are for 18+.** Fine print on paid offers says so.

Examples: "Know the match before it's played." · "Every match we cover, worked out before the toss." · "Free today, then ₹349 a month. Cancel any time."

## Colour

The palette is a cool paper grey, near-black ink and one steel blue, with clay as the second team colour. It reads like a well-made scorebook: calm ground, sharp figures.

- **Grounds:** `bg` for pages, `surface` for raised areas, `steel-900` for navy bands (offers, API panels, the closing call to action). Never pure white pages.
- **Text:** `ink` for headings, `ink-2` for body, `ink-3` for captions. On `steel-900` use `paper`, with `steel-300` and `steel-400` for accents.
- **Accent:** `steel-700` for links, eyebrows and primary buttons on light grounds (5.8:1 with paper text). `steel` is a lighter brand blue for large fills and charts; small text on it is below 4.5:1.
- **Two teams:** team A is always `steel-700` (or `steel` for fills), team B is always `clay`. Wickets are clay rings. Blue and orange differ in lightness, so they stay apart for colour-blind readers.
- **States:** `success`, `warn`, `danger` only for states, never for teams or decoration.
- **Avoid:** gradients as decoration, purple, neon green, more than two hues in one chart.

## Typography

Barlow Condensed for display (uppercase, weight 600), Barlow for text, JetBrains Mono for API code. The files are in `fonts/` (SIL Open Font License, free for commercial use; keep the OFL.txt with them), and all three are on Google Fonts for the web.

- Headlines are short and uppercase: `display` for heroes, `h2` for sections, `h3` for cards.
- Big numbers use `metric` with tabular figures so scores line up.
- Running text stays under 68 characters a line (`measure`).
- One eyebrow per section at most. Don't stack labels above every heading.

## Layout and shape

- **Square by default.** The website uses `radius-none` for buttons, inputs and cards. Posters and social graphics may use `radius-sm` on buttons; the Android app uses `radius-app` cards.
- **Lines, not shadows.** Separate with 1px `line` rules and borders. The only shadow is under a phone or product frame in marketing art.
- **Left-aligned.** Headlines and copy align left; centring is for single short call-to-action bands.
- **Gutters:** at least `space-4` on phones, `space-12` on desktop; content up to `content-max`.

## Charts and illustration

Our pictures are cricket's own charts, drawn in brand colours. No stock photos, no player photos, no team logos.

- **Range bar:** projected score as a dot on a likely-range bar, the median as the big figure and "likely low–high" beside it.
- **Win bar:** one split bar, team A steel-700 on the left, team B clay on the right.
- **Manhattan:** runs per over as bars, wickets as clay rings above them. Used for scale and match story.
- **Wagon wheel:** shot lines from the batter; used to show everything the API covers, with the "six" in clay.
- **Worm:** projected score through the innings, two lines with labelled end values.
- Axis text in `ink-3`, gridlines at `line`, every label names a value the chart reaches.

## Logo

The mark is a chevron (the prompt, a ball leaving the bat) beside three stumps with two bails. The lockup is the mark plus CRIC**SYNTHESIS** in Barlow Condensed 600, uppercase, letter-spaced 0.04em.

- Mark colour `steel-700` on light grounds, `steel-400` on navy. Wordmark: CRIC in `ink` (or `paper` on navy), SYNTHESIS in `steel-700` (or `steel-400`).
- Clear space: the height of one stump bail on every side. Minimum size: mark 20px, lockup 120px wide.
- Don't recolour outside the steel scale, add effects, stretch, or set the wordmark in another face.
- Files are in `logos/`. Use `lockup-on-light.png` on light grounds and `lockup-on-dark.png` on `steel-900`; the single-colour lockups and marks are for one-colour print, embroidery and watermarks. Set the lockup live in Barlow Condensed SemiBold where you can (see `.cs-brand` in `css/brand.css`).

## Iconography

Line icons on a 24px grid, 2px stroke, square caps and joins, `currentColor`. Inside the app they sit in a 44px `surface` tile. Checkmarks in lists are steel-700. No emoji in product UI or marketing.

## Taglines

- Marketing (posters, social, decks): **AI-Powered Cricket Intelligence**.
- Website footer today: "Cricket simulation and analytics". Align the two before using either in a new place.

## Fonts licence

Barlow, Barlow Condensed and JetBrains Mono are licensed under the SIL Open Font License 1.1 (see each `fonts/*/OFL.txt`). You may use, embed and share them, including commercially, as long as the licence file travels with the font files and the fonts are not sold on their own.
